DATA SOURCE:
Deutscher Wetterdienst (German Weather Service), Climate Data Center (CDC)

CITE WITH:
Daten extrahiert vom DWD Climate Data Center (CDC): Title, version, date.
Please note the terms of use as explained at https://opendata.dwd.de/climate_environment/CDC/Nutzungsbedingungen_German.pdf
and for convenience: https://opendata.dwd.de/climate_environment/CDC/Terms_of_use.pdf.
The copyright and rules on citations are explained at the websites of the German Weather Service (Deutscher Wetterdienst).

CONTACT:
Deutscher Wetterdienst
CDC - Vertrieb Klima und Umwelt
Frankfurter Straße 135
63067 Offenbach
tel.: + 49 (0) 69 8062-4400
fax.: + 49 (0) 69 8062-4499
email: klima.vertrieb@dwd.de